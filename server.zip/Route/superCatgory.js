module.exports=(route)=>{
route.get("/",)
}