module.exports={
    getOrder:async(req,res)=>{
        try{

        }
        catch(err){

        }
    },
    addOrder:async(req,res)=>{
        try{

        }
        catch(err){
            
        }
    },
    editOrder:async(req,res)=>{
        try{

        }
        catch(err){
            
        }
    },
    deleteOrder:async(req,res)=>{
        try{

        }
        catch(err){
            
        }
    
    }
}